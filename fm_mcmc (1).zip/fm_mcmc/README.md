# fm_mcmc

This package provides tools for simulating FM signals and analyzing them using Markov Chain Monte Carlo (MCMC).

## Installation

You can install the package using pip:

```bash
pip install .



